#!/bin/bash

nohup ./giov --datadir node/ --testgiov --rpc --rpcaddr 0.0.0.0 --rpcport 6688 --rpcapi personal,db,eth,net,web3,txpool,miner,net,alien > giov.log 2>&1 &


